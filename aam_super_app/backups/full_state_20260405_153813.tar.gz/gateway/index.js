const express = require('express');
const bodyParser = require('body-parser');

const auth = require('../services/auth');
const identity = require('../services/identity');
const wallet = require('../services/wallet');
const music = require('../services/music');
const moderation = require('../services/moderation');
const ads = require('../services/ads');
const ai = require('../services/ai');
const { getConfig } = require('../shared/config');
const { requireAdmin, requireUser } = require('../shared/auth');

const app = express();
const cfg = getConfig();

app.use(bodyParser.json({ limit: '2mb' }));

app.get('/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'gateway',
    appName: cfg.appName,
    environment: cfg.environment,
    time: new Date().toISOString()
  });
});

app.get('/health/detail', (_req, res) => {
  res.json({
    ok: true,
    checks: {
      config: true,
      gateway: true,
      auth: true
    },
    time: new Date().toISOString()
  });
});

app.post('/auth/register', auth.register);
app.post('/auth/login', auth.login);

app.post('/identity/verify', requireAdmin, identity.verify);
app.get('/identity/:userId', requireUser, identity.getUser);

app.post('/wallet/deposit', requireAdmin, wallet.deposit);
app.post('/wallet/transfer', requireUser, wallet.transfer);
app.post('/wallet/platform-split', requireAdmin, wallet.platformSplit);
app.post('/wallet/approve-payout', requireAdmin, wallet.approvePayout);
app.get('/wallet/:userId', requireUser, wallet.getWallet);

app.post('/music/upload', requireUser, music.upload);
app.post('/music/stream', music.streamEvent);

app.post('/moderation/report', moderation.report);
app.post('/moderation/dmca', moderation.dmcaNotice);
app.post('/moderation/appeal', moderation.appeal);

app.post('/ads/impression', ads.impression);
app.get('/admin/ads-summary', requireAdmin, ads.summary);

app.post('/ai/evaluate-stream', ai.evaluateStream);

app.get('/admin/users', requireAdmin, identity.listUsers);
app.get('/admin/wallet-summary', requireAdmin, wallet.summary);
app.get('/admin/tracks', requireAdmin, music.listTracks);
app.get('/admin/stream-summary', requireAdmin, music.streamSummary);
app.get('/admin/mod-summary', requireAdmin, moderation.summary);
app.get('/admin/reports', requireAdmin, moderation.listReports);
app.post('/admin/report-status', requireAdmin, moderation.updateReportStatus);

app.use((err, _req, res, _next) => {
  console.error('UNHANDLED_ERROR', err);
  res.status(500).json({ ok: false, error: 'internal_server_error' });
});

app.use((_req, res) => {
  res.status(404).json({ ok: false, error: 'not_found' });
});

const PORT = process.env.PORT || cfg.port || 4000;
app.listen(PORT, () => console.log(`AAM Gateway on :${PORT}`));
