#!/usr/bin/env bash
set -e
BASE="${1:-http://127.0.0.1:4000}"

echo "== unauthorized user profile should fail =="
curl -s "$BASE/identity/test-user" ; echo

echo "== unauthorized wallet should fail =="
curl -s "$BASE/wallet/test-user" ; echo

echo "== unauthorized admin users should fail =="
curl -s "$BASE/admin/users" ; echo

echo "== bad admin token should fail =="
curl -s "$BASE/admin/users" -H "x-admin-token: BAD_TOKEN" ; echo

echo "== done =="
