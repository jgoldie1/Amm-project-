const fs = require('fs');
const path = require('path');

function loadJson(file, fallback) {
  try {
    const p = path.resolve(file);
    if (!fs.existsSync(p)) {
      fs.writeFileSync(p, JSON.stringify(fallback, null, 2));
      return fallback;
    }
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch (e) {
    return fallback;
  }
}

function saveJson(file, data) {
  const p = path.resolve(file);
  fs.writeFileSync(p, JSON.stringify(data, null, 2));
}

module.exports = { loadJson, saveJson };
