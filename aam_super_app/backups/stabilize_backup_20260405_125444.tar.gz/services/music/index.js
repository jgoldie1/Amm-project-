const { id, now } = require('../../shared/utils');
const { loadJson, saveJson } = require('../../shared/store');
const TRACK_FILE = 'data/tracks.json';
const STREAM_FILE = 'data/streams.json';

function getTracks(){ return loadJson(TRACK_FILE, {}); }
function saveTracks(x){ saveJson(TRACK_FILE, x); }
function getStreams(){ return loadJson(STREAM_FILE, []); }
function saveStreams(x){ saveJson(STREAM_FILE, x); }

exports.upload = (req,res)=>{
  const tracks = getTracks();
  const trackId = id();
  tracks[trackId] = {
    trackId,
    artistId:req.body.artistId,
    title:req.body.title,
    genre:req.body.genre || 'unknown',
    rate:Number(req.body.rate || 0.04),
    remix:req.body.remix || 'open',
    createdAt:now()
  };
  saveTracks(tracks);
  res.json({ok:true, trackId, track:tracks[trackId]});
};

exports.streamEvent = (req,res)=>{
  const tracks = getTracks();
  const streams = getStreams();

  const track = tracks[req.body.trackId];
  if(!track) return res.status(404).json({ok:false, error:'track_not_found'});

  const seconds = Number(req.body.seconds || 0);
  const verified = !!req.body.verified;
  const repeatCount = Number(req.body.repeatCount || 0);

  const qualified = seconds >= 30 && verified && repeatCount < 5;
  const payout = qualified ? track.rate : 0;

  const row = {
    id:id(),
    trackId:track.trackId,
    artistId:track.artistId,
    seconds,
    verified,
    repeatCount,
    qualified,
    payout,
    createdAt:now()
  };

  streams.push(row);
  saveStreams(streams);

  res.json({ok:true, qualified, payout, stream:row});
};
