exports.evaluateStream = (req,res)=>{
  const nudity = Number(req.body.nudity || 0);
  const hate = Number(req.body.hate || 0);
  const copyright = Number(req.body.copyright || 0);
  const risk = Math.min(1, (nudity * 0.5) + (hate * 0.2) + (copyright * 0.3));
  let action = 'allow';
  if (risk >= 0.8) action = 'terminate';
  else if (risk >= 0.5) action = 'pause_review';
  else if (risk >= 0.3) action = 'warn';
  res.json({ok:true, risk, action});
};
