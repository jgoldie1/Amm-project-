const { id, now } = require('../../shared/utils');
const { loadJson, saveJson } = require('../../shared/store');
const FILE = 'data/ads.json';

function rows(){ return loadJson(FILE, []); }
function save(x){ saveJson(FILE, x); }

exports.impression = (req,res)=>{
  const all = rows();
  const row = {
    id:id(),
    adId:req.body.adId || 'free-approved-ad',
    placement:req.body.placement || 'holo-overlay',
    viewerId:req.body.viewerId || 'anon',
    revenue:Number(req.body.revenue || 0),
    at:now()
  };
  all.push(row);
  save(all);
  res.json({ok:true, impression:row});
};
