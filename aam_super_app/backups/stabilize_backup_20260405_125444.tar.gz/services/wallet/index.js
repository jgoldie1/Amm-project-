const { now } = require('../../shared/utils');
const { loadJson, saveJson } = require('../../shared/store');
const DB_FILE = 'data/wallets.json';

function getWallets() {
  return loadJson(DB_FILE, {});
}

function saveWallets(wallets) {
  saveJson(DB_FILE, wallets);
}

function ensure(userId){
  const wallets = getWallets();
  if(!wallets[userId]){
    wallets[userId] = {
      userId,
      balance:0,
      credits:0,
      pending:0,
      lifetimeEarned:0,
      platformFeesPaid:0,
      updatedAt:now()
    };
    saveWallets(wallets);
  }
  return wallets[userId];
}

exports.deposit = (req,res)=>{
  const wallets = getWallets();
  const userId = req.body.userId;
  if(!wallets[userId]) wallets[userId] = ensure(userId);
  wallets[userId].balance += Number(req.body.amount || 0);
  wallets[userId].updatedAt = now();
  saveWallets(wallets);
  res.json({ok:true, wallet:wallets[userId]});
};

exports.transfer = (req,res)=>{
  const wallets = getWallets();
  const from = req.body.from;
  const to = req.body.to;
  const amt = Number(req.body.amount || 0);

  if(!wallets[from]) wallets[from] = ensure(from);
  if(!wallets[to]) wallets[to] = ensure(to);

  if(amt <= 0) return res.status(400).json({ok:false, error:'bad_amount'});
  if(wallets[from].balance < amt) return res.status(400).json({ok:false, error:'insufficient'});

  wallets[from].balance -= amt;
  wallets[to].balance += amt;
  wallets[from].updatedAt = now();
  wallets[to].updatedAt = now();

  saveWallets(wallets);
  res.json({ok:true, from:wallets[from], to:wallets[to]});
};

exports.getWallet = (req,res)=>{
  const wallets = getWallets();
  if(!wallets[req.params.userId]) wallets[req.params.userId] = ensure(req.params.userId);
  saveWallets(wallets);
  res.json({ok:true, wallet:wallets[req.params.userId]});
};

exports.platformSplit = (req,res)=>{
  const wallets = getWallets();
  const creatorId = req.body.creatorId;
  const gross = Number(req.body.gross || 0);
  const platformPct = Number(req.body.platformPct || 30);

  if(!wallets[creatorId]) wallets[creatorId] = ensure(creatorId);
  const fee = +(gross * (platformPct/100)).toFixed(2);
  const net = +(gross - fee).toFixed(2);

  wallets[creatorId].pending += net;
  wallets[creatorId].lifetimeEarned += net;
  wallets[creatorId].platformFeesPaid += fee;
  wallets[creatorId].updatedAt = now();

  saveWallets(wallets);
  res.json({ok:true, gross, platformPct, fee, net, wallet:wallets[creatorId]});
};
