const { id, now } = require('../../shared/utils');
const { loadJson, saveJson } = require('../../shared/store');

const REPORT_FILE = 'data/reports.json';
const DMCA_FILE = 'data/dmca.json';
const APPEAL_FILE = 'data/appeals.json';

function load(file, fallback){ return loadJson(file, fallback); }
function save(file, data){ saveJson(file, data); }

exports.report = (req,res)=>{
  const rows = load(REPORT_FILE, []);
  const r = {
    id:id(),
    contentId:req.body.contentId,
    reason:req.body.reason,
    reporter:req.body.reporter || 'anonymous',
    evidenceWindow:req.body.evidenceWindow || '120s',
    at:now(),
    status:'open'
  };
  rows.push(r);
  save(REPORT_FILE, rows);
  res.json({ok:true, reportId:r.id, report:r});
};

exports.dmcaNotice = (req,res)=>{
  const rows = load(DMCA_FILE, []);
  const n = {
    id:id(),
    claimant:req.body.claimant,
    contentId:req.body.contentId,
    statement:req.body.statement || '',
    at:now(),
    status:'takedown'
  };
  rows.push(n);
  save(DMCA_FILE, rows);
  res.json({ok:true, dmcaId:n.id, action:'content_removed'});
};

exports.appeal = (req,res)=>{
  const rows = load(APPEAL_FILE, []);
  const a = {
    id:id(),
    contentId:req.body.contentId,
    appellant:req.body.appellant || 'unknown',
    reason:req.body.reason || '',
    at:now(),
    status:'pending'
  };
  rows.push(a);
  save(APPEAL_FILE, rows);
  res.json({ok:true, appealId:a.id, appeal:a});
};
