const { id, now } = require('../../shared/utils');
const { loadJson, saveJson } = require('../../shared/store');
const DB_FILE = 'data/users.json';

function getUsers() {
  return loadJson(DB_FILE, {});
}

function saveUsers(users) {
  saveJson(DB_FILE, users);
}

exports.signup = (req,res)=>{
  const users = getUsers();
  const userId = id();
  users[userId] = {
    userId,
    email: req.body.email || '',
    age: Number(req.body.age || 0),
    parentId: req.body.parentId || null,
    verified:false,
    trustScore:0,
    role:req.body.role || 'creator',
    createdAt: now()
  };
  saveUsers(users);
  res.json({ok:true, userId});
};

exports.verify = (req,res)=>{
  const users = getUsers();
  const u = users[req.body.userId];
  if(!u) return res.status(404).json({ok:false, error:'user_not_found'});
  u.verified = true;
  u.trustScore = Number(u.trustScore || 0) + 10;
  u.verifiedAt = now();
  saveUsers(users);
  res.json({ok:true, verified:true, trustScore:u.trustScore});
};
