const { id, now } = require('../../shared/utils');
const { loadJson, saveJson } = require('../../shared/store');
const { ok, fail, num } = require('../../shared/http');

const DB_FILE = 'data/users.json';

function getUsers() {
  return loadJson(DB_FILE, {});
}

function saveUsers(users) {
  saveJson(DB_FILE, users);
}

exports.signup = (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const age = num(req.body.age, 0);
  const role = String(req.body.role || 'creator').trim();

  if (!email) return fail(res, 400, 'email_required');
  if (age < 0) return fail(res, 400, 'invalid_age');

  const users = getUsers();
  const exists = Object.values(users).find(u => u.email === email);
  if (exists) return fail(res, 409, 'email_exists', { userId: exists.userId });

  const userId = id();
  users[userId] = {
    userId,
    email,
    age,
    parentId: req.body.parentId || null,
    verified: false,
    trustScore: 0,
    role,
    status: 'active',
    createdAt: now()
  };

  saveUsers(users);
  return ok(res, { userId, user: users[userId] });
};

exports.verify = (req, res) => {
  const userId = String(req.body.userId || '').trim();
  if (!userId) return fail(res, 400, 'userId_required');

  const users = getUsers();
  const user = users[userId];
  if (!user) return fail(res, 404, 'user_not_found');

  user.verified = true;
  user.trustScore = num(user.trustScore, 0) + 10;
  user.verifiedAt = now();

  saveUsers(users);
  return ok(res, { verified: true, trustScore: user.trustScore, user });
};

exports.getUser = (req, res) => {
  const users = getUsers();
  const user = users[req.params.userId];
  if (!user) return fail(res, 404, 'user_not_found');
  return ok(res, { user });
};

exports.listUsers = (_req, res) => {
  const users = Object.values(getUsers());
  return ok(res, { count: users.length, users });
};
