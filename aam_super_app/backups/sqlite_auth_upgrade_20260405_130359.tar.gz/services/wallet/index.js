const { now } = require('../../shared/utils');
const { loadJson, saveJson } = require('../../shared/store');
const { ok, fail, num } = require('../../shared/http');
const { getConfig } = require('../../shared/config');

const DB_FILE = 'data/wallets.json';
const TX_FILE = 'data/transactions.json';

function getWallets() {
  return loadJson(DB_FILE, {});
}
function saveWallets(wallets) {
  saveJson(DB_FILE, wallets);
}
function getTxs() {
  return loadJson(TX_FILE, []);
}
function saveTxs(rows) {
  saveJson(TX_FILE, rows);
}

function ensure(wallets, userId) {
  if (!wallets[userId]) {
    wallets[userId] = {
      userId,
      balance: 0,
      credits: 0,
      pending: 0,
      lifetimeEarned: 0,
      platformFeesPaid: 0,
      updatedAt: now()
    };
  }
  return wallets[userId];
}

function addTx(type, payload) {
  const rows = getTxs();
  rows.push({
    type,
    ...payload,
    createdAt: now()
  });
  saveTxs(rows);
}

exports.deposit = (req, res) => {
  const userId = String(req.body.userId || '').trim();
  const amount = num(req.body.amount, 0);
  if (!userId) return fail(res, 400, 'userId_required');
  if (amount <= 0) return fail(res, 400, 'invalid_amount');

  const wallets = getWallets();
  const wallet = ensure(wallets, userId);
  wallet.balance += amount;
  wallet.updatedAt = now();
  saveWallets(wallets);

  addTx('deposit', { userId, amount });
  return ok(res, { wallet });
};

exports.transfer = (req, res) => {
  const from = String(req.body.from || '').trim();
  const to = String(req.body.to || '').trim();
  const amount = num(req.body.amount, 0);

  if (!from || !to) return fail(res, 400, 'from_to_required');
  if (amount <= 0) return fail(res, 400, 'invalid_amount');

  const wallets = getWallets();
  const fromWallet = ensure(wallets, from);
  const toWallet = ensure(wallets, to);

  if (fromWallet.balance < amount) return fail(res, 400, 'insufficient_balance');

  fromWallet.balance -= amount;
  toWallet.balance += amount;
  fromWallet.updatedAt = now();
  toWallet.updatedAt = now();

  saveWallets(wallets);
  addTx('transfer', { from, to, amount });

  return ok(res, { from: fromWallet, to: toWallet });
};

exports.platformSplit = (req, res) => {
  const creatorId = String(req.body.creatorId || '').trim();
  const gross = num(req.body.gross, 0);
  const cfg = getConfig();
  const platformPct = num(req.body.platformPct, cfg.platformFeePercent);

  if (!creatorId) return fail(res, 400, 'creatorId_required');
  if (gross <= 0) return fail(res, 400, 'invalid_gross');
  if (platformPct < 0 || platformPct > 100) return fail(res, 400, 'invalid_platformPct');

  const wallets = getWallets();
  const wallet = ensure(wallets, creatorId);

  const fee = +(gross * (platformPct / 100)).toFixed(2);
  const net = +(gross - fee).toFixed(2);

  wallet.pending += net;
  wallet.lifetimeEarned += net;
  wallet.platformFeesPaid += fee;
  wallet.updatedAt = now();

  saveWallets(wallets);
  addTx('platform_split', { creatorId, gross, platformPct, fee, net });

  return ok(res, { gross, platformPct, fee, net, wallet });
};

exports.getWallet = (req, res) => {
  const userId = String(req.params.userId || '').trim();
  if (!userId) return fail(res, 400, 'userId_required');

  const wallets = getWallets();
  const wallet = ensure(wallets, userId);
  saveWallets(wallets);

  return ok(res, { wallet });
};

exports.summary = (_req, res) => {
  const wallets = Object.values(getWallets());
  const totals = wallets.reduce((acc, w) => {
    acc.balance += num(w.balance);
    acc.credits += num(w.credits);
    acc.pending += num(w.pending);
    acc.lifetimeEarned += num(w.lifetimeEarned);
    acc.platformFeesPaid += num(w.platformFeesPaid);
    return acc;
  }, { balance: 0, credits: 0, pending: 0, lifetimeEarned: 0, platformFeesPaid: 0 });

  return ok(res, { count: wallets.length, totals });
};
