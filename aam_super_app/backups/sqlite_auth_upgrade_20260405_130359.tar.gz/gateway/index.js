const express = require('express');
const bodyParser = require('body-parser');

const identity = require('../services/identity');
const wallet = require('../services/wallet');
const music = require('../services/music');
const moderation = require('../services/moderation');
const ads = require('../services/ads');
const ai = require('../services/ai');
const { getConfig } = require('../shared/config');

const app = express();
const cfg = getConfig();

app.use(bodyParser.json({ limit: '2mb' }));

app.get('/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'gateway',
    appName: cfg.appName,
    environment: cfg.environment,
    time: new Date().toISOString()
  });
});

app.get('/health/detail', (_req, res) => {
  res.json({
    ok: true,
    checks: {
      config: true,
      gateway: true
    },
    time: new Date().toISOString()
  });
});

app.post('/identity/signup', identity.signup);
app.post('/identity/verify', identity.verify);
app.get('/identity/:userId', identity.getUser);
app.get('/admin/users', identity.listUsers);

app.post('/wallet/deposit', wallet.deposit);
app.post('/wallet/transfer', wallet.transfer);
app.post('/wallet/platform-split', wallet.platformSplit);
app.get('/wallet/:userId', wallet.getWallet);
app.get('/admin/wallet-summary', wallet.summary);

app.post('/music/upload', music.upload);
app.post('/music/stream', music.streamEvent);
app.get('/admin/tracks', music.listTracks);
app.get('/admin/stream-summary', music.streamSummary);

app.post('/moderation/report', moderation.report);
app.post('/moderation/dmca', moderation.dmcaNotice);
app.post('/moderation/appeal', moderation.appeal);
app.get('/admin/mod-summary', moderation.summary);
app.get('/admin/reports', moderation.listReports);

app.post('/ads/impression', ads.impression);
app.get('/admin/ads-summary', ads.summary);

app.post('/ai/evaluate-stream', ai.evaluateStream);

app.use((err, _req, res, _next) => {
  console.error('UNHANDLED_ERROR', err);
  res.status(500).json({ ok: false, error: 'internal_server_error' });
});

app.use((_req, res) => {
  res.status(404).json({ ok: false, error: 'not_found' });
});

const PORT = process.env.PORT || cfg.port || 4000;
app.listen(PORT, () => console.log(`AAM Gateway on :${PORT}`));
