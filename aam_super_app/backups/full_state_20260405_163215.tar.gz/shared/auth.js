const jwt = require('jsonwebtoken');
const { getConfig } = require('./config');

function requireAdmin(req, res, next) {
  const cfg = getConfig();
  const token = req.headers['x-admin-token'];
  if (token !== cfg.adminToken) {
    return res.status(403).json({ ok: false, error: 'admin_forbidden' });
  }
  next();
}

function requireUser(req, res, next) {
  const cfg = getConfig();
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;

  if (!token) {
    return res.status(401).json({ ok: false, error: 'auth_required' });
  }

  try {
    const payload = jwt.verify(token, cfg.jwtSecret);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ ok: false, error: 'invalid_token' });
  }
}

module.exports = { requireAdmin, requireUser };
