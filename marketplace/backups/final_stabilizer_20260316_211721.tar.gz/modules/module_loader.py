from pathlib import Path
import importlib.util
import datetime

def _log(msg):
    Path("logs").mkdir(exist_ok=True)
    with open("logs/module_failures.log", "a", encoding="utf-8") as f:
        f.write(f"[{datetime.datetime.now()}] {msg}\n")

def load_optional_modules(app):
    modules_dir = Path("modules")
    for path in sorted(modules_dir.glob("*.py")):
        if path.name in {"recovery_core.py", "module_loader.py", "__init__.py"}:
            continue
        try:
            spec = importlib.util.spec_from_file_location(path.stem, str(path))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            if hasattr(mod, "register"):
                mod.register(app)
        except Exception as e:
            _log(f"FAILED {path.name}: {e.__class__.__name__}: {e}")
